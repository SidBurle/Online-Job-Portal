import Header from './Header'
import Wrapper from './Wrapper'
export default function EmployerHomePage(p) {
    return (
        <>
        <Header isEmployer={true} />
        <Wrapper isEmployer={true} />
        </>
    )
};
